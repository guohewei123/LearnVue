<template>
  <div id="app">123</div>
</template>

<style lang="scss">
</style>
