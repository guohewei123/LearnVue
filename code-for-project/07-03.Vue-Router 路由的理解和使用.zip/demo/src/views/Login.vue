<template>
  <div >
    loginPage
  </div>
</template>

<script>
export default {
  name: 'LoginPage',
}
</script>
